<!doctype html>
<html>
<head>
<meta charset="utf-8">

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="website/styleb1.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<title>Admin register</title>
</head>

<body>

<div class="container" style="padding-top: 10px;">
<div class="row">
	<div class="col-md-8">
	<form class="form-horizontal" role="form" action="forgetpass_send_mail.php">
	   <h1 style="font-family: Baskerville, 'Palatino Linotype', Palatino, 'Century Schoolbook L', 'Times New Roman', 'serif'; margin-left: 120px;color: #399097; font-weight:500; padding-bottom: 30px;">FORGET PASSWORD </h1>
	
		<div class="form-group">
			<label for="To" class="control-label col-sm-2">Email:</label>
			<div class="col-sm-3 col-lg-6">
				<input type="email" id="email" required name="email" class="form-control" >
			</div>
		</div>
		
     <input type="submit" class="btn-success" value="Submit" name="ok" style="margin-left: 200px;">
		</form>
	</div>
   </div>
	</div>
</body>
</html>
